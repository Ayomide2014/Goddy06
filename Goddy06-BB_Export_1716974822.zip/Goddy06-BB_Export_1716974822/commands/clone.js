/*CMD
  command: clone
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

BBAdmin.installBot({
email:"adnetworkau@gmail.com",
bot_id: bot.id})
Bot.sendMessage("sent")
